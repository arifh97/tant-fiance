import React from 'react'

export default function Brands() {
  return (
    <div>Brands</div>
  )
}
