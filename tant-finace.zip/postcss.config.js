export default {
    plugins: {
        tailwindcss: {},
        autoprefixer: {},
        // 'postcss-url': {
        //     url: 'inline', // Inline images as data URLs
        //     maxSize: 10, // Maximum file size to inline (in kilobytes)
        //     fallback: 'copy', // Fallback for larger files
        // },
    },
}